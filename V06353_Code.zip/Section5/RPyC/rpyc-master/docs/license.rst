.. _license:

License
=======
RPyC is released under the *MIT license*:

  .. literalinclude:: ../LICENSE

