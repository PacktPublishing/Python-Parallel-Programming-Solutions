.. _api-registry:

Registry
========

.. automodule:: rpyc.utils.registry
   :members:
