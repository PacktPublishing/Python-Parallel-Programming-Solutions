.. _api-authenticators:

Authenticators
==============

.. automodule:: rpyc.utils.authenticators
   :members:


