.. _api-service:

Service
=======

.. automodule:: rpyc.core.service
   :members:

