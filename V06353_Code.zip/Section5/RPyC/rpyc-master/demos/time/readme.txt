A canonical example of a basic service:
 * time_service.py defines the service
 * server.py exposes the service
 * client.py utilizes the service
    - NOTE requires registry_server.py to be running
